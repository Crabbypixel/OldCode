#include <stdio.h>
#include <conio.h>
#include <graphics.h>

void main()
{
 int a,b,c=0;
 textcolor(YELLOW);
 clrscr();
 cprintf("A simple Sum Program\n");
 printf("\n");
 textcolor(RED);
 cprintf("Enter the First Number: ");
 scanf("%d",&a);
 textcolor(GREEN);
 cprintf("Enter the Second Number: ");
 scanf("%d",&b);                3
 c= a+b;
 textcolor(BLUE);
 cprintf("The sum of First and Second Number is %d",c);
 getch();
}