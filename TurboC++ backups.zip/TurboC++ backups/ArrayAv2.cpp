#include <stdio.h>
#include <conio.h>
#include <graphics.h>

void main()
{
  int i=1,n=1,sum=0,a[5];
  float avg=0;
  clrscr();

  printf("\nHi I can find average of any given integers");
  printf("\nFor how many numbers, do you want to find average?: ");
  scanf("%d",&n);

  for (i=1;i<=n;i++)
  {
   printf("\nEnter value for %d: ",i);
   scanf("%d",&a[i]);
   sum=sum+a[i];
  }
  avg=sum/n;
  printf("\n\nAverage of above given numbers is: %5.2f", avg);
  getch();
}
