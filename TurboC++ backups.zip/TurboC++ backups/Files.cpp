#include <stdio.h>
#include <conio.h>
#include <graphics.h>
#include <math.h>

typedef struct
{ int adm_no;
  int marks;
} record;

FILE *fpt;

main()
{
 record student;
 record read_input(record);
 fpt=fopen("student.txt", "w");
 if (fpt==NULL)
  {printf("\nUnable to open student.txt file");

  }

  clrscr();

  printf("\nEnter 2 students admission number and marks");

  printf("\nEnter 1st student admission num: ");
  scanf("%d",&student.adm_no);
  printf("Enter 1st student marks: ");
  scanf("%d",&student.marks);
  fwrite(&student,sizeof(record),1,fpt);

  printf("\nEnter 2nd student admission num: ");
  scanf("%d",&student.adm_no);
  printf("Enter 2nd student marks: ");
  scanf("%d",&student.marks);
  fwrite(&student,sizeof(record),1,fpt);

  fclose(fpt);
  return 0;
}
