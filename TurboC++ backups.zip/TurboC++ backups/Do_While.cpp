#include <stdio.h>
#include <conio.h>
#include <graphics.h>

void main()
{
 int x;
 clrscr();
 do
 {
  printf("\nHello Surya\n");
  printf("Do you want to continue? Press 1 for YES 0 for No and Enter Key ");
  scanf("%d",&x);
 }
 while (x==1);
 printf("\nThank you for using our program - by JAISURYA VETRIVEL\n");

 getch();
}
