#include <iostream.h>
#include <conio.h>
#include <graphics.h>

class Student_Details
{
 private:
   char Name[50];
   int Age;
   char Hobby[50];
 public:
   //Inputs the Details
   void Input_Details(void);
   //Displays the Details
   void Display_Details(void);
};

void Student_Details::Input_Details(void)
{
 cout<<endl;
 cout<<"Enter the Student Details"<<endl;
 cout<<"Enter the Student Name: "<<endl;
 cin>>Name;
 cout<<"Enter the Student Age: "<<endl;
 cin>>Age;
 cout<<"Enter the Student Favourite Hobby: "<<endl;
 cin>>Hobby;
 cout<<endl;
}

void Student_Details::Display_Details(void)
{
 cout<<endl;
 cout<<"The Student's Details"<<endl;
 cout<<"The Student's Name: "<<Name<<endl;
 cout<<"The Student's Age: "<<Age<<endl;
 cout<<"The Student's Faviurite Hobby: "<<Hobby<<endl;
}

int main()
{
 Student_Details std[100];
 int loop,i;
 clrscr();

 cout<<"The Student Details"<<endl;
 cout<<"Enter the Number of Students: "<<endl;
 cin>>i;

 for(loop=0;loop<i;loop++)
 {
  cout<<"Input the Details of Student "<<loop+1<<endl;
  std[loop].Input_Details();
 }

 for(loop=0;loop<i;loop++)
 {
  cout<<"The Details of Student "<<loop+1<<endl;
  std[loop].Display_Details();
  cout<<endl;
 }

 getch();
 return 0;
}