#include <stdio.h>
#include <conio.h>
#include <graphics.h>
#include <ctype.h>

void main()
{
 char ch;
 printf("Enter any Character: ");
 scanf("%c",&ch);
 if(isalpha(ch))
 {
  if(isupper (ch))
   printf("The converted Character is: %c",tolower(ch));
  else
   printf("The converted character is: %c",toupper (ch));
 }
 else
  printf("Not an Alphabet");
  getch();
}
