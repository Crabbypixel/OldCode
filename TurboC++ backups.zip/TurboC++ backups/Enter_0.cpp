#include <stdio.h>
#include <conio.h>
#include <graphics.h>

void main()
{ int x=1;
  clrscr();
  while (x!=0)
  { printf("Hi Dude...I am printing this message untill you press 0: ");
    scanf("%d",&x);
  }
    printf("\n\nEND!!");
    getch();
}