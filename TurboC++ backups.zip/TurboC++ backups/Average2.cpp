#include <stdio.h>
#include <conio.h>
#include <graphics.h>

void main()
{
    float avg=0,sum=0;
    int n=0;
    clrscr();
    printf("Hi, I can find The Average of 5 numbers");

    printf("\nEnter the 1st number: "); scanf("%d",&n);
    sum=sum+n;

    printf("Enter the 2nd Number: "); scanf("%d",&n);
    sum=sum+n;

    printf("Enter the 3rd Number: "); scanf("%d",&n);
    sum=sum+n;

    printf("Enter the 4th Number: "); scanf("%d",&n);
    sum=sum+n;

    printf("Enter the 5th Number: "); scanf("%d",&n);
    sum=sum+n;

    avg=sum/5;

    printf("\nSum of the Given Numbers: %6.2f",sum);
    printf("\nThe Average of the Above Numbers: %6.2f",avg);
    getch();
}

