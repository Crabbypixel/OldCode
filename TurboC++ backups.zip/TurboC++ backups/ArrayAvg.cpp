#include <stdio.h>
#include <conio.h>
#include <graphics.h>
#include <math.h>

void main()
{
  int i,a[5];
  float avg=0;
  clrscr();

  printf("\nHi I can find average of any 5 integers");

  for (i=1;i<=5;i++)
  {
   printf("\nEnter value for %d: ",i); scanf("%d",&a[i]);
   avg=avg+a[i];
  }

  printf("\n\nAverage of above given numbers is: %5.2f", avg/5);
  getch();
}
