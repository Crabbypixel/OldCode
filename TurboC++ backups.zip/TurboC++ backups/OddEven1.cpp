/*Program to find odd or even number by mathematical method
using 3 variables*/

#include <stdio.h>
#include <conio.h>
#include <graphics.h>
void main()
{
   int x,y,z;
   clrscr();
   printf("\nHi..I can check whether given number is ODD/EVEN");
   printf("\nNow enter a number: ");
   scanf("%d", &x);

   y=x/2;
   z=x-y*2;

   if(z==0)
     printf("Given number is an EVEN number");
   else
     printf("Given number is an ODD number");

   getch();
}
