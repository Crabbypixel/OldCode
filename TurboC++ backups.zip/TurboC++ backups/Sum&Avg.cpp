#include <stdio.h>
#include <conio.h>
#include <graphics.h>

void main()
{
  int a[100],count,sum,n,i=0;
  float avg;
  clrscr();
  printf("Enter the Number of the Elements but less than 100: ");
  scanf("%d",&n);
  for(count=0,sum=0; count<n; count++)
  {
    printf("Enter the %d Element",i+1);
    scanf("%d",&a[i]);
    sum+=a[i];
  }
  avg=(float)sum/n;
  printf("\nSum of the numbers= %d and average =%6.2f",sum,avg);
  getch();
}

















