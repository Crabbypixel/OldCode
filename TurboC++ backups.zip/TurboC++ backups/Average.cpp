#include <stdio.h>
#include <conio.h>
#include <graphics.h>

void main()
{
    float avg;
    int sum,num1,num2,num3,num4,num5;
    clrscr();
    printf("Hi, I can The Average of 5 numbers");
    printf("\nEnter the 1st number: ");
    scanf("%d",&num1);
    printf("Enter the 2nd Number: ");
    scanf("%d",&num2);
    printf("Enter the 3rd Number: ");
    scanf("%d",&num3);
    printf("Enter the 4th Number: ");
    scanf("%d",&num4);
    printf("Enter the 5th Number: ");
    scanf("%d",&num5);

    printf("\nThe Given Numbers are %d, %d, %d, %d, %d", num1,num2,num3,num4,num5);

    sum=num1+num2+num3+num4+num5;
    printf("\nThe Sum of the above Numbers: %d",sum);

    avg=(num1+num2+num3+num4+num5)/5;
    printf("\nThe Aveage of the Above Numbers: %5.2f",avg);
    getch();

}