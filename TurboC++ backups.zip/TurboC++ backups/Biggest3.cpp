#include <stdio.h>
#include <conio.h>
#include <graphics.h>

void main()
{
 int a,b,c;
 clrscr();
 printf("Enter any 3 Character: ");
 scanf("%f%f%f",&a,&b,&c);
 if(a>b && a>c)
  printf("The %f Number is the Biggest!",a);
 else if(b>c)
  printf("The %f Number is the Biggest!",b);
 else
  printf("The %f Number is the Biggest!",c);
 getch();
}