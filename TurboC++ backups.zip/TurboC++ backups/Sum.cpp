#include <stdio.h>
#include <conio.h>

void main()
{
  int a,b,c;
  printf("Enter any Number: ");
  scanf("%d",&a);
  printf("Enter The second Number: ");
  scanf("%d",&b);
  c=a+b;
  printf("The Sum of 'a' and 'b' is %d",c);
  printf("Thank you for using our Program!!!");
  getch();
}