//Program to find greatst of 2 numbers
#include <stdio.h>
#include <conio.h>
#include <graphics.h>

void main()
{
    int a,b;
    clrscr();
    printf("Hi I can find the greatest of 2 numbers\n");
    printf("Enter the First Number: ");
    scanf("%d", &a);
    printf("Enter the Second Number: ");
    scanf("%d", &b);

    printf("The Number you have Entered are: %d and %d\n ", a,b);

    if(a>b)
    printf("%d is Greater", a);

    else
    printf("%d is Greater", b);
    getch();
}