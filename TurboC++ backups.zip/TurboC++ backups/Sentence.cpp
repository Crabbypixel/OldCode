#include <stdio.h>
#include <conio.h>
#include <graphics.h>

void main()
{
  int a;
  clrscr();
  printf("Hello Students, have you done your homework?\n");
  printf("Sorry Madam, I forgot to do my homework, forgive me, I will do tommorow.\n");
  printf("\n");
  printf("Why all did not do your homework?\n");
  printf("Sorry madam, I forgot to Do my Homework, forgive me, I will do it tommmorow.\n");
  printf("\n");
  printf("Surya, Why did not do your Homework?\n");
  printf("Sorry Madam, I forgot to do my homework, forgive me, I will do it tommorow.\n");
  printf("\n");
  printf("Kevin, Why did not do yesterday's Homework?\n");
  printf("Sory Madam, I forgot to do Homework, forgive me, i will do it tommorow.\n");
  getch();
}