#include <stdio.h>
#include <conio.h>
#include <graphics.h>

void main()
{
  int a,b,c,d,n,r;
  clrscr();
  printf("Hi, I can REVERSE 4 digit Number :)");
  printf("\nEnter 4 Digit Number: ");
  scanf("%d",&n);
  a=n%10;
  b=(n/10)%10;
  c=(n%100)%10;
  d=n/1000;
  r=(a*1000) + (b*100) + (c*10) + d;
  printf("The REVERSED Number is: %d", r);
  getch();
}