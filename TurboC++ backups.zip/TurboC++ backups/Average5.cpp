//Finding average using For Loop
#include <stdio.h>
#include <conio.h>
#include <graphics.h>

void main()
{
    int i=0,n=0,sum=0;
    float avg=0;
    clrscr();
    printf("Hi, I can find The Average 5 numbers using For Loop");
    for(i=1;i<=5;i++)
    {
       printf("\nEnter the Value for %d: ",i);
       scanf("%d",&n);
       sum=sum+n;
    }
    //printf("Enter the Value for Number %d",i);
    avg=sum/5;
    printf("The Sum of The Above Numbers: %d", sum);
    printf("\nThe Average of the above numbers: %5.2f", avg);
    getch();
}