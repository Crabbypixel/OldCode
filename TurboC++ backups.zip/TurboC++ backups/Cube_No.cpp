#include <iostream.h>
#include <conio.h>

float cube(float);

float main()
{
 float x,y;
 float ans;
 clrscr();
 cout<<"Enter value for X: "<<endl;
 cin>>x;
 cout<<"Enter value for Y: "<<endl;
 cin>>y;

 ans=(cube(x)+cube(y))/cube(x*y);

 cout<<"The answer is: "<<ans;
 getch();
 return 0;
}

float cube(float a)
{
 return a*a*a;
}

