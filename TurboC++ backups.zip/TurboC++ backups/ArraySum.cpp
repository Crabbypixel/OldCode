#include <stdio.h>
#include <conio.h>
#include <graphics.h>

void main()
{
   int a[5],i,sum=0;
   clrscr();
   printf("Hi\n");
   printf("Enter any 5 Numbers: ");

   for(i=1;i<=5;i++)
   scanf("%d",&a[i]);

   printf("\nGiven numbers are below\n");
   for(i=1;i<=5;i++)
   printf("\n%d",a[i]);


   for(i=1;i<=5;i++)
   sum=sum+a[i];

   printf("\nSum of above Numbers: %d\n",sum);

   printf("\nULTA\n");
   for(i=5;i>=1;i--)
   printf("\n%d", a[i]);


  // scanf("%d",&i);
  // printf("%d", a[i]);

   printf("\nEnd!!!");
   getch();
}



























































































