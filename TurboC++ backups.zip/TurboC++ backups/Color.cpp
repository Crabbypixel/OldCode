#include <stdio.h>
#include <conio.h>
#include <graphics.h>

void main()
{
 int a,b,c;
 textcolor(BLUE);
 clrscr();
 cprintf("This is my First Color Text\n");
 textcolor(WHITE);
 textbackground(YELLOW);
 cprintf("Hello World!!!\n");
 textattr(WHITE+BLINK); //This Blink will make the Next Character To Blink
 cputs("Bye!!!");
 getch();
}