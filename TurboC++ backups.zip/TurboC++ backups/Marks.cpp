#include <stdio.h>
#include <conio.h>
#include <graphics.h>

void main()
{
  int rollno[5]={1001,1002,1003,1004,1005};
  int sci[5], maths[5];
  int i;
  clrscr();
  for(i=0;i<=4;i++)
  {
   printf("Enter the Science Marks for %d: ", rollno[i]);
   scanf("%d",&sci[i]);
   printf("\n");
  }
  for(i=0;i<=4;i++)
  {
   printf("Enter the Maths Marks for %d: ", rollno[i]);
   scanf("%d",&maths[i]);
   printf("\n");
  }
  printf("\n---------");
  printf("\nMark List");
  printf("\nRollNo  Science  Maths");
  printf("\n------  -------  -----");

  for(i=0;i<=4;i++)
  printf("\n%d :  %d   %d:\n",rollno[i],sci[i],maths[i]);
  printf("\n\n");
  printf("Thank you for using our program!!!");
  printf("Bye!!!");
  getch();
}
















































































































































































































































