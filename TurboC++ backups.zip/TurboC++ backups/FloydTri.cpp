//Floyd's Triangle
#include <stdio.h>
#include <conio.h>
#include <graphics.h>

void main()
{
   int r,c,n,i,j;
   clrscr();
   printf("Hello I can display Floyd's Triangle");
   printf("\nEnter the number of ROWS");
   scanf("%d", &r);
   n=1;

   for(i=1; i<=r; i++)
   {
     for(j=1;j<=i;j++)
     {
     printf("%2d", n);
     ++n;
     }
     printf("\n\n");
     }
     getch();
}







































































































