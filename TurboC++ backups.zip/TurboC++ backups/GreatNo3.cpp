#include <stdio.h>
#include <conio.h>
#include <graphics.h>

void main()
{
   float x;
   clrscr();
   printf("Enter an Number less than TEN LAKHS\n");
   scanf("%f", &x);

   if(x<10)
   printf("It is a One Digit Number\n");

   else if(x<100)
   printf("It is a Two Digit Number\n");

   else if(x<1000)
   printf("It is a Three Digit Number\n");

   else if(x<10000)
   printf("It is a Four Digit Number\n");

   else if(x<100000)
   printf("It is a Five Digit Number\n");

   else if(x<1000000)
   printf("It is a Six Digit Number");

   else
   printf("Invalid Number");

   getch();
}